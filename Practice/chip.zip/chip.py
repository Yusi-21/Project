import pygame
import sys
from random import randint
from pathlib import Path

class Chip:
    def __init__(self, font, rom):
        self.mem = [0] * 4096
        self.V = [0] * 16
        self.I = 0
        self.pc = 512
        self.sp = 0
        self.stack = [0] * 16
        self.scr = [0] * (64 * 32)  # Экран 64x32
        self.key = [0] * 16
        self.delay_timer = 0
        self.sound_timer = 0
        for i in range(80):
            self.mem[i] = font[i]
        for i in range(len(rom)):
            self.mem[i + 512] = rom[i]

        # Инициализация pygame для вывода
        pygame.init()
        self.screen = pygame.display.set_mode((64 * 10, 32 * 10))  # Размер экрана 640x320
        pygame.display.set_caption("CHIP-8 Emulator")

    def load_rom(chip, rom_path):
        with open(rom_path, "rb") as file:
            rom_data = file.read()

        for i, byte in enumerate(rom_data):
            chip.mem[512 + i] = byte  # Загружаем ROM с адреса 0x200

    def draw_screen(self):
        for y in range(32):
            for x in range(64):
                color = (0, 255, 0) if self.scr[y * 64 + x] == 1 else (0, 0, 0)
                pygame.draw.rect(self.screen, color, pygame.Rect(x * 10, y * 10, 10, 10))  # Рисуем пиксели
        pygame.display.update()

    def clear_screen(self):
        self.scr = [0] * (64 * 32)  # Очистка экрана

    def handle_keys(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    self.key[0] = 1
                elif event.key == pygame.K_2:
                    self.key[1] = 1
                elif event.key == pygame.K_3:
                    self.key[2] = 1
                elif event.key == pygame.K_4:
                    self.key[3] = 1
                # Добавьте другие клавиши здесь...

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_1:
                    self.key[0] = 0
                elif event.key == pygame.K_2:
                    self.key[1] = 0
                elif event.key == pygame.K_3:
                    self.key[2] = 0
                elif event.key == pygame.K_4:
                    self.key[3] = 0
                # Добавьте другие клавиши здесь...

def step(chip):
    mem, V, stack, scr, key = chip.mem, chip.V, chip.stack, chip.scr, chip.key
    npc = chip.pc + 2
    opc = mem[chip.pc] << 8 | mem[chip.pc + 1]
    op1 = opc & 0xf000
    op2 = opc & 0xf00f
    op3 = opc & 0xf0ff

    if opc == 0x00e0:
        chip.clear_screen()  # Очистка экрана
    elif opc == 0x00ee:
        chip.sp -= 1
        npc = stack[chip.sp]
        npc += 2
    elif op1 == 0x1000:
        npc = opc & 0x0FFF
    elif op1 == 0x2000:
        stack[chip.sp] = chip.pc
        chip.sp += 1
        npc = opc & 0x0FFF
    elif op1 == 0x3000:
        if V[(opc & 0x0F00) >> 8] == (opc & 0x00FF):
            npc = chip.pc + 4
    elif op1 == 0x4000:
        if V[(opc & 0x0F00) >> 8] != (opc & 0x00FF):
            npc = chip.pc + 4
    elif op1 == 0x5000:
        if V[(opc & 0x0F00) >> 8] == V[(opc & 0x00F0) >> 4]:
            npc = chip.pc + 4
    elif op1 == 0x6000:  # Новая инструкция
        V[(opc & 0x0F00) >> 8] = opc & 0x00FF
    elif op1 == 0x7000:
        V[(opc & 0x0F00) >> 8] += opc & 0x00FF
    elif op2 == 0x8000:
        V[(opc & 0x0F00) >> 8] = V[(opc & 0x00F0) >> 4]
    elif op2 == 0x8001:
        V[(opc & 0x0F00) >> 8] |= V[(opc & 0x00F0) >> 4]
    elif op2 == 0x8002:
        V[(opc & 0x0F00) >> 8] &= V[(opc & 0x00F0) >> 4]
    elif op2 == 0x8003:
        V[(opc & 0x0F00) >> 8] ^= V[(opc & 0x00F0) >> 4]
    elif op2 == 0x8004:
        V[(opc & 0x0F00) >> 8] += V[(opc & 0x00F0) >> 4]
        if V[(opc & 0x00F0) >> 4] > (0xFF - V[(opc & 0x0F00) >> 8]):
            V[0xF] = 1
        else:
            V[0xF] = 0
    elif op2 == 0x8005:
        #TODO
        if V[(opc & 0x00F0) >> 4] > V[(opc & 0x0F00) >> 8]:
            V[0xF] = 0
        else:
            V[0xF] = 1
        V[(opc & 0x0F00) >> 8] -= V[(opc & 0x00F0) >> 4]
    elif op2 == 0x8006:
        V[0xF] = V[(opc & 0x0F00) >> 8] & 0x1
        V[(opc & 0x0F00) >> 8] >>= 1
    elif op2 == 0x8007:
        #TODO
        if V[(opc & 0x0F00) >> 8] > V[(opc & 0x00F0) >> 4]:
            V[0xF] = 0
        else:
            V[0xF] = 1
        V[(opc & 0x0F00) >> 8] = V[(opc & 0x00F0) >> 4] - V[(opc & 0x0F00) >> 8]
    elif op2 == 0x800e:
        #TODO
        V[0xF] = V[(opc & 0x0F00) >> 8] >> 7
        V[(opc & 0x0F00) >> 8] <<= 1
    elif op1 == 0x9000:
        if V[(opc & 0x0F00) >> 8] != V[(opc & 0x00F0) >> 4]:
            npc = chip.pc + 4
    elif op1 == 0xa000:
        chip.I = opc & 0x0FFF
    elif op1 == 0xb000:
        npc = (opc & 0x0FFF) + V[0]
    elif op1 == 0xc000:
        V[(opc & 0x0F00) >> 8] = randint(0, 255) & (opc & 0x00FF)
    elif op1 == 0xd000:
        x = V[(opc & 0x0F00) >> 8]
        y = V[(opc & 0x00F0) >> 4]
        height = opc & 0x000F
        V[0xF] = 0
        for yline in range(height):
            pixel = mem[chip.I + yline]
            for xline in range(8):
                if (pixel & (0x80 >> xline)) != 0:
                    # Оборачиваем координаты
                    x_coord = (x + xline) % 64
                    y_coord = (y + yline) % 32
                    if scr[y_coord * 64 + x_coord] == 1:
                        V[0xF] = 1
                    scr[y_coord * 64 + x_coord] ^= 1

    elif op3 == 0xe09e:
        if key[V[(opc & 0x0F00) >> 8]] != 0:
            npc = chip.pc + 4
    elif op3 == 0xe0a1:
        if key[V[(opc & 0x0F00) >> 8]] == 0:
            npc = chip.pc + 4
    elif op3 == 0xf007:
        V[(opc & 0x0F00) >> 8] = chip.delay_timer
    elif op3 == 0xf00a:
        #TODO
        pass
    elif op3 == 0xf015:
        chip.delay_timer = V[(opc & 0x0F00) >> 8]
    elif op3 == 0xf018:
        chip.sound_timer = V[(opc & 0x0F00) >> 8]
    elif op3 == 0xf01e:
        if chip.I + V[(opc & 0x0F00) >> 8] > 0xFFF:
            V[0xF] = 1
        else:
            V[0xF] = 0
        chip.I += V[(opc & 0x0F00) >> 8]
    elif op3 == 0xf029:
        chip.I = V[(opc & 0x0F00) >> 8] * 0x5
    elif op3 == 0xf033:
        mem[chip.I] = V[(opc & 0x0F00) >> 8] // 100
        mem[chip.I + 1] = (V[(opc & 0x0F00) >> 8] // 10) % 10
        mem[chip.I + 2] = V[(opc & 0x0F00) >> 8] % 10
    elif op3 == 0xf055:
        for i in range(((opc & 0x0F00) >> 8) + 1):
            mem[chip.I + i] = V[i]
        chip.I += ((opc & 0x0F00) >> 8) + 1
    elif op3 == 0xf065:
        for i in range(((opc & 0x0F00) >> 8) + 1):
            V[i] = mem[chip.I + i]
        chip.I += ((opc & 0x0F00) >> 8) + 1
    else:
        print("invalid opcode 0x%x at 0x%x" % (opc, chip.pc))
        sys.exit(1)
    if chip.delay_timer > 0:
        chip.delay_timer -= 1
    if chip.sound_timer > 0:
        chip.sound_timer -= 1
    chip.pc = npc


font = Path("font.bin").read_bytes()
rom = Path("roms/tetris.rom").read_bytes()
chip = Chip(font, rom)

while True:
    chip.handle_keys()  # Обрабатываем ввод с клавиатуры через метод экземпляра
    step(chip)  # Выполняем инструкцию
    chip.draw_screen()  # Обновляем экран
    pygame.time.delay(16)  # Задержка, чтобы не перегрузить CPU
